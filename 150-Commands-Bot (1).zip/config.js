exports.TOKEN = 'ODU1MDU5Mjk4MDA1Mjg2OTEy.YMs-Bg.KJmtIGGMF0TtfmIKs-9z_3OxPz4';

exports.PREFIX = '+';

exports.news_API = '7a96e21c019947e89738164fc37510a3';

exports.giphy_API = 'z1flPcNNs7rUsloX5X1Rr5GWtDbEcSS2';

exports.AME_API = 'bb03f373caa534fcfcbaeae177a65134f44a6e57ba7a7b098be273867b376d8a677ddae3c23c6ded4fec8288573945e8c3483689deb13f229376ad4b5b60231d';
